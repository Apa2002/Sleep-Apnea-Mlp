import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from tensorflow.keras.models import load_model


binary_features = ['Gendermale1', 'BloodPressure', 'BMICategory']
numeric_features = ['Age', 'QualityofSleep', 'PhysicalActivityLevel', 'HeartRate']

preprocessor = ColumnTransformer(
    transformers=[
        ('binary', MinMaxScaler(), binary_features),
        ('numeric', StandardScaler(), numeric_features),
    ]
)


sample_data = pd.DataFrame({
    'Gendermale1': [1],
    'BloodPressure': [1],
    'Age': [30],
    'QualityofSleep': [7],
    'PhysicalActivityLevel': [5],
    'HeartRate': [75],
    'BMICategory': [1]
})


preprocessor.fit(sample_data)


model = load_model(r'C:\Users\pasan\OneDrive\Desktop\ANN\codes\رابط کاربری در سی شارپ\model.h5')


user_input = {
    'Gendermale1': 1,
    'BloodPressure': 1,
    'Age': 25,
    'QualityofSleep': 8,
    'PhysicalActivityLevel': 6,
    'HeartRate': 70,
    'BMICategory': 0
}


user_df = pd.DataFrame([user_input])


user_input_processed = preprocessor.transform(user_df)


prediction = model.predict(user_input_processed)[0][0]
result = "Likely to have sleep apnea" if prediction >= 0.5 else "Not likely to have sleep apnea"

print(result)
