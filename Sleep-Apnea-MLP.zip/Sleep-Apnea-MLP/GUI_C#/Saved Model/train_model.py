
import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Input
import tensorflow as tf

# Set random seed for reproducibility
tf.random.set_seed(42)
np.random.seed(42)

# Load the dataset
from google.colab import drive
drive.mount('/content/drive')
file_path = '/content/drive/MyDrive/withouticorvalcheack.xlsx'
data = pd.read_excel(file_path)

# Define columns based on types
binary_features = ['Gendermale1', 'BloodPressure', 'BMICategory']
numeric_features = ['Age', 'QualityofSleep', 'PhysicalActivityLevel', 'HeartRate']
target = 'SleepDisorder'

# Define ColumnTransformer for preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('binary', MinMaxScaler(), binary_features),
        ('numeric', StandardScaler(), numeric_features),
    ]
)

# Separate features (X) and target variable (y)
X = data.drop(columns=[target])
y = data[target]

# Apply preprocessing to the entire dataset
X = preprocessor.fit_transform(X)

# Build the model
def build_model(input_dim):
    model = Sequential([
        Input(shape=(input_dim,)),
        Dense(10, activation='relu'),
        Dense(3, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

# Train the model on the entire dataset
model = build_model(input_dim=X.shape[1])
model.fit(X, y, epochs=50, batch_size=32, verbose=1)

# Save the model
model.save('model.h5')
