﻿namespace WindowsFormsApplication7
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.bt1start = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt1start
            // 
            this.bt1start.BackColor = System.Drawing.SystemColors.Info;
            this.bt1start.Location = new System.Drawing.Point(24, 112);
            this.bt1start.Name = "bt1start";
            this.bt1start.Size = new System.Drawing.Size(160, 79);
            this.bt1start.TabIndex = 0;
            this.bt1start.Text = "Start";
            this.bt1start.UseVisualStyleBackColor = false;
            this.bt1start.Click += new System.EventHandler(this.bt1start_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BackgroundImage = global::WindowsFormsApplication7.Properties.Resources.Dahlia_Red_Flower_Background_508;
            this.ClientSize = new System.Drawing.Size(551, 442);
            this.Controls.Add(this.bt1start);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Button bt1start;
    }
}
