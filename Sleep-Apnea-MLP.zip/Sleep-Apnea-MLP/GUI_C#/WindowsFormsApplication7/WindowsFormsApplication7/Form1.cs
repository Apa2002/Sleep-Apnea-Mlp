﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // اینجا می‌توانید کدهای مربوط به بارگذاری اولیه فرم را اضافه کنید
        }

     

        private void bt1start_Click_1(object sender, EventArgs e)
        {
            
            string gender = Prompt.ShowDialog("Enter Gender (1 for male, 0 for female):", "Input Gender");
            string bloodPressure = Prompt.ShowDialog("Enter Blood Pressure (1 for high, 0 for normal):", "Input Blood Pressure");
            string age = Prompt.ShowDialog("Enter Age:", "Input Age");
            string qualityOfSleep = Prompt.ShowDialog("Enter Quality of Sleep (1 to 10):", "Input Quality of Sleep");
            string physicalActivity = Prompt.ShowDialog("Enter Physical Activity Level (1 to 10):", "Input Physical Activity Level");
            string heartRate = Prompt.ShowDialog("Enter Heart Rate:", "Input Heart Rate Per Minute");
            string bmiCategory = Prompt.ShowDialog("Enter BMI Category (1 for high, 0 for normal):", "Input BMI Category");

            string pythonPath = @"C:\Users\pasan\AppData\Local\Programs\Python\Python312\python.exe";
            string scriptPath = @"C:\Users\pasan\OneDrive\Desktop\ANN\codes\رابط کاربری در سی شارپ\predict_apnea.py";

           
            string arguments = "\"" + scriptPath + "\" " +
                               gender + " " +
                               bloodPressure + " " +
                               age + " " +
                               qualityOfSleep + " " +
                               physicalActivity + " " +
                               heartRate + " " +
                               bmiCategory;

            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = pythonPath,
                Arguments = arguments,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            try
            {
                using (Process process = Process.Start(start))
                {
                    using (System.IO.StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd(); // نتیجه پیش‌بینی
                        MessageBox.Show("Prediction Result: " + result, "Prediction", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    using (System.IO.StreamReader errorReader = process.StandardError)
                    {
                        string error = errorReader.ReadToEnd();
                        if (!string.IsNullOrEmpty(error))
                        {
                            MessageBox.Show("Error: " + error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }

    // کلاس برای نمایش پنجره ورودی
    public static class Prompt
    {
        public static string ShowDialog(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 400,
                Height = 200,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 20, Top = 20, Text = text, AutoSize = true };
            TextBox textBox = new TextBox() { Left = 20, Top = 50, Width = 340 };
            Button confirmation = new Button() { Text = "OK", Left = 140, Width = 100, Top = 100, DialogResult = DialogResult.OK };
            confirmation.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(textBox);
            prompt.Controls.Add(confirmation);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }
}
